package com.dicoding.javafundamental.objek;
 
public class Main {
    public static void main(String[] args) {
        Hewan babi = new Hewan("babi");
        Hewan anjing = new Hewan("anjing");


        babi.beratHewan(4);
        babi.jumlahKakiHewan(4);
        babi.cetakHewan();


        anjing.beratHewan(3);
        anjing.jumlahKakiHewan(2);
        anjing.cetakHewan();
    }
}

